package com.sebastian_daschner.learning_java_ee.cars.entity;

public enum EngineType {

    DIESEL, PETROL, ELECTRIC

}

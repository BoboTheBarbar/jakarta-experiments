package com.sebastian_daschner.learning_java_ee.entity;

public enum SeatMaterial {

    VINYL, LEATHER

}

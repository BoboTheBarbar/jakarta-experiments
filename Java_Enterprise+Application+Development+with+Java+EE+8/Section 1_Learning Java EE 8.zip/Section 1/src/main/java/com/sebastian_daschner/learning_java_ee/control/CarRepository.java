package com.sebastian_daschner.learning_java_ee.control;

import com.sebastian_daschner.learning_java_ee.entity.Car;

public class CarRepository {
    public void store(Car car) {
        // ...
    }
}

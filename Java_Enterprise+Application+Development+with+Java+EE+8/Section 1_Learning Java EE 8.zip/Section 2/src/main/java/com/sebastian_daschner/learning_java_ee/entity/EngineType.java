package com.sebastian_daschner.learning_java_ee.entity;

public enum EngineType {

    DIESEL, PETROL, ELECTRIC

}
